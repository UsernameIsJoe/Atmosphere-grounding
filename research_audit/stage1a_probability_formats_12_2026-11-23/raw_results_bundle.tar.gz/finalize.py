import pathlib,time,subprocess,json
p=pathlib.Path('/workspace/probability_formats_2026_11_23')
try:
 start=time.time()
 while not (p/'COMPLETE.json').exists():
  assert not (p/'FAILED.json').exists(),(p/'FAILED.json').read_text()
  assert time.time()-start<1200,'bounded finalize wait expired'
  time.sleep(1)
 subprocess.run(['python',str(p/'analyze_qwen.py')],check=True)
 subprocess.run(['python',str(p/'package_results.py')],check=True)
 (p/'FINALIZED.json').write_text(json.dumps({'time':time.time(),'bundle':json.loads((p/'BUNDLE.json').read_text())}))
 print('FINALIZED',flush=True)
except BaseException as e:
 (p/'FINALIZE_FAILED.json').write_text(json.dumps({'time':time.time(),'error':repr(e)}));raise
