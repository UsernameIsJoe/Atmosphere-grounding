import pathlib,json,time,subprocess,os,signal
p=pathlib.Path('/workspace/probability_repeat_2026_11_23')
try:
 start=time.time()
 while not (p/'COMPLETE.json').exists():
  assert not (p/'FAILED.json').exists(),(p/'FAILED.json').read_text()
  assert time.time()-start<180,'completion timeout'
  time.sleep(.5)
 pid=int((p/'server_pid.txt').read_text())
 cmd=pathlib.Path('/proc')/str(pid)/'cmdline'
 assert b'ollama' in cmd.read_bytes() and b'serve' in cmd.read_bytes()
 os.kill(pid,signal.SIGTERM)
 time.sleep(1)
 (p/'service_stop.json').write_text(json.dumps({'pid':pid,'signal':'SIGTERM','time':time.time(),'after_native_and_direct_completion':True}))
 for script in ['analyze_repeat.py','analyze_cache.py','package_results.py']:
  subprocess.run(['python',str(p/script)],check=True)
 (p/'FINALIZED.json').write_text(json.dumps({'time':time.time(),'bundle':json.loads((p/'BUNDLE.json').read_text())}))
 print('FINALIZATION_COMPLETE',flush=True)
except BaseException as e:
 (p/'FINALIZATION_FAILED.json').write_text(json.dumps({'error':repr(e),'time':time.time()}))
 raise
