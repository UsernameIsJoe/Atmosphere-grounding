"""Glide: typed decisions (choice / yes-no / score) with a probability for every option, one forward pass per question."""
from .model import Glide
from .prompt import RequestError

__version__ = "1.2.0"
__all__ = ["Glide", "RequestError", "__version__"]
