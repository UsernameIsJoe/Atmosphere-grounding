"""Recurrent-depth inference: middle blocks of layers run more than once inside the single forward pass.

Configured by the `midloop` field of decision_config.json:

    {"strategy": "euler", "conv": "A", "blocks": [[24, 35], [36, 47]], "passes": 2, "n_gate": 0, "n_lora": 0, ...}

Each block [a, b] (inclusive layer indices) is a function G made of those layers with their usual weights. With P passes, the block's
input x_0 (the hidden states entering layer a) is updated with damped Euler steps:

    x_k = (1 - 1/P) * x_{k-1} + (1/P) * G(x_{k-1}),   k = 1 .. P,

and x_P is passed on to layer b + 1. The first G(x_0) is the normal pass through the block. Blocks run in order, so a later block starts
from an earlier block's output. Every pass sees the whole sequence with the same masks and positions as the normal forward pass. The
interpolation is computed in fp32 and cast back to the model dtype.

There are no extra parameters and no generated tokens: the same weights, one call per question, P - 1 extra passes over each block.
With passes = 1 the computation is the plain model.
"""
from __future__ import annotations

import torch
import transformers.models.qwen3_5.modeling_qwen3_5 as QM


def resolve(cfg: dict) -> dict:
    """Validate the `midloop` configuration (only the parameter-free damped-Euler form is supported)."""
    c = dict(cfg or {})
    if c.get("strategy", "euler") != "euler" or c.get("conv", "A") != "A":
        raise ValueError(f"unsupported recurrence configuration: {c}")
    if int(c.get("n_gate") or 0) or int(c.get("n_lora") or 0):
        raise ValueError("this package supports the parameter-free recurrence only (n_gate = n_lora = 0)")
    blocks = c.get("blocks") or [[int(c["a"]), int(c["b"])]]
    c["blocks"] = sorted([(int(a), int(b)) for a, b in blocks], key=lambda w: w[1])
    c["passes"] = int(c.get("passes") or 1)
    if c["passes"] < 1 or any(not 0 <= a <= b for a, b in c["blocks"]):
        raise ValueError(f"invalid recurrence configuration: {c}")
    return c


def _lerp(h, y, g):
    """h + g * (y - h) in fp32, cast back to h's dtype."""
    hf = h.float()
    return (hf + g * (y.float() - hf)).to(h.dtype)


class RecurrentTextModel(QM.Qwen3_5TextModel):
    """Qwen3_5TextModel whose layer loop applies the block recurrence (module docstring). The code around the layer loop follows
    transformers 5.17.0's Qwen3_5TextModel.forward without the cache paths (one-pass scoring only)."""

    recurrence = None

    def forward(self, input_ids=None, attention_mask=None, position_ids=None, past_key_values=None, inputs_embeds=None, use_cache=None,
                **kwargs):
        if past_key_values is not None or use_cache:
            raise NotImplementedError("recurrent depth: no KV / recurrent cache (one-pass scoring only)")
        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("You must specify exactly one of input_ids or inputs_embeds")
        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)
        if position_ids is None:
            position_ids = torch.arange(inputs_embeds.shape[1], device=inputs_embeds.device)
            position_ids = position_ids.view(1, 1, -1).expand(4, inputs_embeds.shape[0], -1)
        elif position_ids.ndim == 2:
            position_ids = position_ids[None, ...].expand(4, position_ids.shape[0], -1)
        if position_ids.ndim == 3 and position_ids.shape[0] == 4:
            text_position_ids = position_ids[0]
            position_ids = position_ids[1:]
        else:
            text_position_ids = None
        if not isinstance(causal_mask_mapping := attention_mask, dict):
            mask_kwargs = {"config": self.config, "inputs_embeds": inputs_embeds, "attention_mask": attention_mask, "past_key_values": None,
                           "position_ids": text_position_ids}
            causal_mask_mapping = {"full_attention": QM.create_causal_mask(**mask_kwargs),
                                   "linear_attention": QM.create_recurrent_attention_mask(**mask_kwargs)}
        hidden_states = inputs_embeds
        position_embeddings = self.rotary_emb(hidden_states, position_ids)
        types = self.config.layer_types
        n = self.config.num_hidden_layers
        layers = self.layers[:n]
        c = self.recurrence
        P, blocks = c["passes"], c["blocks"]

        def run(i, h):
            return layers[i](h, position_embeddings=position_embeddings, attention_mask=causal_mask_mapping[types[i]],
                             position_ids=text_position_ids, past_key_values=None, use_cache=use_cache, **kwargs)

        def G(x, a, b):
            for j in range(a, b + 1):
                x = run(j, x)
            return x

        x0s = {}
        for i in range(n):
            if P > 1:
                for k, (a, b) in enumerate(blocks):
                    if i == a:
                        x0s[k] = hidden_states            # the block's input
            hidden_states = run(i, hidden_states)
            if P > 1:
                for k, (a, b) in enumerate(blocks):
                    if i == b:                            # hidden_states = G(x_0), the normal pass through the block
                        x = x0s[k]
                        for step in range(1, P + 1):
                            gx = hidden_states if step == 1 else G(x, a, b)
                            x = _lerp(x, gx, 1.0 / P)
                        hidden_states = x
        hidden_states = self.norm(hidden_states)
        return QM.Qwen3_5ModelOutputWithPast(last_hidden_state=hidden_states, past_key_values=None)


def attach(backbone, cfg: dict) -> dict:
    """Switch a Qwen3_5TextModel to the recurrent forward. No parameters are added. Returns the resolved configuration."""
    c = resolve(cfg)
    if max(b for _, b in c["blocks"]) >= backbone.config.num_hidden_layers:
        raise ValueError("recurrence block beyond the last layer")
    backbone.__class__ = RecurrentTextModel
    backbone.recurrence = c
    return c
